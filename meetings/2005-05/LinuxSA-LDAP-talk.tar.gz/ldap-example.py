#!/usr/bin/env python

import ldap


ldap_connection = ldap.open("localhost")
ldap_connection.simple_bind_s("cn=Matthew Geddes,ou=People,dc=LinuxSA,dc=org,c=AU", "crud")
results = ldap_connection.search_s("dc=LinuxSA,dc=org,c=AU", ldap.SCOPE_SUBTREE, "cn~=Matt")

num_entries = len(results)
print "# Returned %d entries" % num_entries

for entry in results:
  dn = entry[0]
  print "dn: %s" % dn
  for attribute in entry[1]:
    for value in entry[1][attribute]:
      if attribute != 'jpegPhoto':
        print "%s: %s" % (attribute, value)
  print ""

