/**
 * @file shm.c
 *
 * @mainpage shm
 *
 * @section history History
 *
 * @subsection original Original code
 * @author David J. Schwartz <davids@webmaster.com>
 * @version 1.03
 *
 *  Put into the public domain. Please keep the acknowledgement above
 *  intact. Portions taken from the NTP source (the time_shm structure
 *  and attach_shm code) are covered by the NTP copyright/license.
 *
 * @subsection parallel Parallel port code
 * @author gnu@wraith.sf.ca.us
 * @version 0.9
 *
 * @subsubsection Changes
 * @version v0.1 prune dead code
 * @date 21 jul 2003
 * @version 0.2 "might be a bug" fix with PPCLRIRQ
 * @version 0.3 revert fix--causes 40ms offset.
 * @date 22 jul 2003
 * @version 0.4 flap pin 14 a la freebsd
 * @version 0.5 fix poll argument
 * @version 0.6 debug, syslog instrumentation
 * @date 23 jul 2003
 * @version 0.7 getopt handling, merge parallel and serial versions
 * @version 0.8 optionize flapping of pin 14
 * @version 0.9 multiple unit support
 *
 * @subsection daemon Daemon and logging code
 * @author glen.turner@aarnet.edu.au
 * @subsubsection Changes
 * @date 2003-10-30  Add functions usually expected of a daemon.
 *                   BSD-style code conventions (sorry, customer requirement)
 * @date 2003-11-10  Move tolerance from compile-time constant to -t parameter
 *
 * @section Wiring
 *   Centronics parallel
 *      DB-25    Name   Connect to
 *      Pin 10   -Ack   Inverted PPS in from GPS
 *      Pin 22   Gnd    Ground (any other ground signal will do just as well)
 *      Pin 14          Software-echoed PPS (see -f option)
 *   RS-232 serial
 *      DB-25   DB-9    Pin name       Connect to
 *      Pin 8   Pin 1   DCD or RLSD    PPS in from GPS
 *      Pin 7   Pin 5   Gnd            Ground
 *
 * @section usage Usage
 *
 * @subsection modules Kernel modules
 * Kernel modules for parallel
 * @verbatim
 *   modprobe parport_pc io-0x378 irq=7
 *   modprobe ppdev
 * @endverbatim
 * Ensure that lp module does not use the port (eg, no parallel
 * printer is configured).
 *
 * @subsection examples Examples
 * Parallel example
 * @verbatim
 *   shm -i /var/run/shm.pid -p /dev/parport0
 * @endverbatim
 *
 * Serial example
 * @verbatim
 *   shm -i /var/run/shm.pid -s /dev/ttyS0
 * @endverbatim
 *
 * Fault-finding example
 * @verbatim
 *   shm -B -D -V -i /var/run/shm.pid -p /dev/parport0
 * @endverbatim
 *
 * @subsection ntpconf NTP configuration
 * @li You should have a line like the following in your
 *     @c {/etc/ntpd.conf}
 *        @c {server 127.127.28.0}
 * @li Make sure no 'restrict' statement in your conf file prevents
 *     you from trusting the clock. If in doubt, add:
 *        @c {restrict 127.127.28.0}
 * @li You must configure NTPD with the SHM clock driver
 *
 * @section compile Compile
 *   Compile to minimise memory, be deterministic, and be fast,
 *   in that order:
 *
 *    gcc -O2 -Os -static -fomit-frame-pointer -DNDEBUG -march=pentium4
 *    -mfpmath=sse -malign-double -minline-all-stringops -s -o shm
 *    shm.c
 *
 *   modified appropiately for your CPU.  See the Makefile.
 *
 * @section daemoncontrol Daemon control
 *   Sending a TERM or INT leads to a clean exit.
 *
 *   Sending a HUP causes a reload. The input port is closed and
 *   opened.  If the reflected PPS signal was disabled due to failure
 *   then it is retried.  The statistics on time accuracy are not
 *   reset -- this allows port issues to be fixed without perturbing
 *   time keeping too much.
 *
 * @section todo To do
 * @todo
 *  Average multiple PPS readings together, filtering out those that
 *  appear to be 'late'.
 *
 * @todo
 *  Have two states, synchronized and unsynchronized. Start in the
 *  unsynchronized state. If synchronized, go unsynchronized if most
 *  readings exceed the threshold. If unsynchronized, go synchronized
 *  if 'sysinfo' indicates a reasonable stratum and root distance.
 *
 */

#ifndef linux
#error "Linux-specfic code"
#endif

#define _GNU_SOURCE 1

#include <sys/types.h>
#include <sys/ipc.h> /* For shm...() */
#include <sys/shm.h> /* For shm...() */
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/ioctl.h>  /* For ioctl(). */
#include <termios.h>  /* For tcgetattr(), tcsetattr(). */
#include <asm/ioctls.h>
#include <sched.h>
#include <fcntl.h>
#include <unistd.h>  /* For fork(), setsid(), setpgrp(), close(), getpid(). */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>  /* For exit(), atoi(). */
#include <errno.h>  /* For errno. */
#include <limits.h>  /* For INT_MAX */
#include <stdarg.h>  /* For va_() */
#include <signal.h>  /* For SIG*, signal() */
#include <assert.h>

#include <syslog.h>
#include <sys/poll.h>
#include <sys/utsname.h>
#include <linux/ppdev.h>
#include <linux/parport.h>

#include <getopt.h>

/**
 * Accept a timestamp if it's within this many microseconds of the
 * system's second boundary -- do not exceed 250000.
 * Setting this low helps avoid false lock, but requires a more
 * accurate starting time synchronization. Setting this high makes
 * capture easier but risks false lock if the clock starts too far
 * off.
 */
#define TOLERANCE_DEFAULT 40000
/* #define TOLERANCE_MAX 250000 */
#define TOLERANCE_MAX 499999

/**
 * Assume it takes this long for us to get scheduled and get the time
 * (in microseconds).
 */
#define ASSUME_DELAY 0

/**
 * Accuracy is assumed to be 2^PRECISION seconds.
 * -11 is approximately 490uS This is just an initial estimate, it
 * will be adjusted.
 */
#define PRECISION (-11)

/**
 * Options to syslog().
 */
#define LOG_OPTIONS (LOG_PID)

/**
 * Distinguish runtime and parse failures.
 * <stdlib.h>'s EXIT_FAILURE is used for run time failure.
 */
#define EXIT_PARSE_FAILURE 2

/**
 * No interface option.
 */
#define OPTIONS_INTERFACE_NONE 0
/**
 * Serial port interface option.
 */
#define OPTIONS_INTERFACE_SERIAL 1
/**
 * Parallel port interface option.
 */
#define OPTIONS_INTERFACE_PARALLEL 2
/**
 * Command line options.
 */
struct options_t {
#ifndef NDEBUG
    /**
     * When true,output log_debug() messages. Only possible when
     * compiled without @c {NDEBUG}.
     */
    int debug;
#endif
    /**
     * When true, signals are detected on voltage fall, not voltage
     * rise.
     */
    int hightolow;
    /**
     * When non-NULL contains the name of a file to contain the
     * process ID for use by the System V init system.
     */
    char *pidfile;
    /**
     * When true, do not create a daemon process.
     */
    int nodaemon;
    /**
     * When true, echo pulse-per-second input on parallel input pin
     * onto parallel output pin.
     */
    int flap;
    /**
     * The pulse-per-second interface. One of INTERFACE_SERIAL,
     * INTERFACE_PARALLEL or INTERFACE_NONE (which indicates an
     * erroe).
     */
    int interface;
    /**
     * Tolerance from system clock, in ms. Pulses arriving outside of
     * this tolerance are ignored.
     */
    int tolerance;
    /**
     * SHM unit number.
     */
    int unit;
    /**
     * When true, output is sent to stderr rather than to syslog.
     */
    int verbose;
    /**
     * The path of the device attached to the pulse-per-second source.
     */
    char *device;
};
/**
 * Command line options.
 */
static struct options_t options;

/**
 * Program name and version.
 */
#define PROGRAM_NAME "shm"
/* Put RCS identifier into a special place in the ELF object file. */
#ident "@(#) $Id: shm.c,v 1.6 2003/11/09 19:36:49 gdt Exp gdt $"
/**
 * Source code file and revision identifier from the Revision Control
 * System.
 */
static char const rcs_id[] = "$Id: shm.c,v 1.6 2003/11/09 19:36:49 gdt Exp gdt $";
/* Version for Doxygen
 * @version $Version$
 */

/**
 * Error summaries.
 */
struct statistics_t {
    /**
     * Number of fatal errors since program start.
     */
    unsigned long errors;
    /**
     * Number of non-fatal errors since program start.
     */
    unsigned long warnings;
    /**
     * Number of pulse-per-second clock pulses since program start.
     */
    unsigned long pulses;
    /**
     * Number of clock or non-clock pulses on the serial port since
     * program start.
     */
    unsigned long serial_pulses;
    /**
     * Number of clock pulses the arrival time has been rounded
     * upwards.
     */
    unsigned long round_up;
    /**
     * Number of clock pulses the arrival time has been rounded
     * downwards.
     */
    unsigned long round_down;
    /**
     * Number of clock pulses the capability of the rounding algorthm
     * has been exceeded.
     */
    unsigned long round_exceeded;
    /**
     * Number of clock pulses when precision lost.
     */
    unsigned long precision_loss;
    /**
     * Number of clock pulses when precision gained.
     */
    unsigned long precision_gain;
};
/**
 * Statistics summarising pulse-per-second clock behaviour and actions
 * of rounding and precision algorithms.
 */
static struct statistics_t statistics;


/**
 * PID file existence and name.
 */
static char *pidfile = NULL;

/**
 * Format of name for a Linux serial port lock file.
 *
 * @bug The same device can have multiple names, and thus the locking
 * can fail to ensure one attempt to use the device.
 */
#define LOCKFILE_FORMAT "/var/lock/LCK..%s"
#define LOCKFILE_SIZE FILENAME_MAX
/**
 * Serial port lock file.
 */
static char lockfile[LOCKFILE_SIZE] = { '\0' };

/**
 * Terminal status before we change it, we use this to restore the
 * terminal settings on exit.
 */
static int original_term_valid = 0;
static struct termios original_term;

/**
 * Signal status.
 */
#define SIGNAL_RECEIVED_NONE 0
#define SIGNAL_RECEIVED_EXIT (SIGTERM)
#define SIGNAL_RECEIVED_RELOAD (SIGHUP)
static int signal_received = SIGNAL_RECEIVED_NONE;

/**
 * Size, padding, etc must match NTPD's struct time_shm.
 */
struct time_shm
{
 int shm_mode;
 int stamp_count;
 time_t clock_sec;
 int clock_usec;
 time_t receive_sec;
 int receive_usec;
 int leap_indicator;
 int precision;
 int number_of_samples;
 int is_valid;
 int place_holder[10];
};

/**
 * GCC allows programmers to supply branch prediction, we do this in
 * the tight PPS loop.  That gives deterministic performance (even if
 * the programmer-supplied prediction is wrong).
 */
#ifndef __GNUC__
#define __builtin_expect(EXPR, C) (EXPR)
#endif

/* Local function prototypes.
 * All functions are static so the optimising compiler can perform well.
 */
static void log_detail(int, const char *, const char *, int, const char *,
                       ...);
static void exit_failure(void);
static void help(FILE *);
static char *options_interface_str(int);
static int parse_options(int, char *[], struct options_t *);
static void signal_handler_exit(int);
static void signal_handler_reload(int);
static void signal_handlers(void);
static void become_daemon(int);
static char *pidfile_set(char *);
static void pidfile_clear(char *);
static void lockfile_name(char *, size_t, char *, char *);
static void lockfile_set(char *);
static void lockfile_clear(char *);
static void lower_jitter(void);
static int parallel_open(char *);
static int serial_open(char *);
static void parallel_pps(int, struct time_shm *, struct timeval *, int);
static void serial_pps(int, struct time_shm *, struct timeval *, int);
static void parallel_close(int);
static void serial_close(int);
static struct time_shm *attach_shm(int);
static inline int difference(int, int);
static void update_offset(int, int *);
static void stamp_shm(struct time_shm *, time_t, int, time_t, int, int);
static void frobtrans(struct time_shm *, struct timeval *);


/**
 * Print a message.
 *
 * Try not to use this directly; rather use log() for messages and
 * log_debug() for debugging.
 *
 * @param priority  (in)  LOG_INFO, LOG_NOTICE, LOG_ERR.
 * @param file      (in)  Source file name.
 * @param function  (in)  Source function name.
 * @param line      (in)  Source file line number.
 * @param format    (in)  A printf-style format string.
 * @param  ...      (in)  Optional parameters to the format string.
 */
static void
log_detail(int priority,
           const char *file,
           const char *function,
           int line,
           const char *format,
           ...)
{
    va_list args;
    int print;

    /* When compiled for debugging, print debug messages only
     * if options.debug.
     */
#ifndef NDEBUG
    if (priority == LOG_DEBUG) {
        print = options.debug;
    }
    else {
        print = 1;
    }
#else
    print = 1;
#endif

    if (print) {
        if (options.verbose) {
            fprintf(stderr,
                    "%s:%d %s(): priority %d: ",
                    file,
                    line,
                    function,
                    priority);
            va_start(args, format);
            vfprintf(stderr, format, args);
            va_end(args);
            if (errno) {
                fprintf(stderr,
                       ": %s (errno %d)",
                       strerror(errno),
                       errno);
            }
            fprintf(stderr, "\n");
        }
        else
        {
            openlog(PROGRAM_NAME, LOG_OPTIONS, LOG_DAEMON);
            va_start(args, format);
            vsyslog(priority, format, args);
            va_end(args);
            if (errno) {
                syslog(priority,
                       "    system error %d: %s",
                       errno,
                       strerror(errno));
            }
            /* Log source code details when that is interesting. */
            if (priority != LOG_INFO && priority != LOG_NOTICE) {
                syslog(priority,
                       "    source file %s function %s() line %d",
                       file,
                       function,
                       line);
            }
            closelog();
        }
    }

    if (priority == LOG_WARNING) {
        statistics.warnings++;
    }
    else if (priority == LOG_ERR) {
        statistics.errors++;
    }
}


/**
 * Log a message.
 *
 * @param priority (in)  LOG_NOTICE, LOG_WARNING, LOG_ERR.
 * @param format   (in)  A printf() format constant.
 *                         format must be known at compile-time,
 *                         it cannot be a variable.
 * @param ...      (in)  Optional format arguments.
 */
#define log(priority, format, ...) log_detail(priority, __FILE__, __func__, __LINE__, format, ##__VA_ARGS__)


/**
 * Debugging mesages
 *
 * To use compile without NDEBUG and set "debug" to non-zero.
 * To remove, compile with NDEBUG defined.
 *
 * @param format  (in)  A printf() format constant.
 * @param ...     (in)  Optional format arguments.
 */
#ifndef NDEBUG
#define log_debug(format, ...) log_detail(LOG_DEBUG, __FILE__, __func__, __LINE__, "Debug: " format, ##__VA_ARGS__)
#else
/* Make the function empty
 * The odd form of this makes C's syntax continue to work as expected
 * in if...else statements without braces.
 */
#define log_debug(format, ...) while (0) { }
#endif


/**
 * Display the value of options.interface as text rather than
 * numerically.
 *
 * @param options_interface  (in)  Value of options.interface.
 * @return Pointer to string with English description of option.
 */
static char *
options_interface_str(int options_interface)
{
    if (options_interface == OPTIONS_INTERFACE_NONE) {
        return "none";
    }
    if (options_interface == OPTIONS_INTERFACE_SERIAL) {
        return "serial";
    }
    if (options_interface == OPTIONS_INTERFACE_PARALLEL) {
        return "parallel";
    }
    return "!unknown!";
}


/**
 * Write initial log messages, including parsed options.
 *
 * @param options  (in)  parsed command line options
 */
void
log_options(struct options_t *options)
{
    struct utsname u;

    log(LOG_INFO,
        "Source: %s",
        rcs_id);
    log_detail(LOG_INFO,
               __FILE__,
               __func__,
               __LINE__,
               "Build: "
#ifdef __GNUC__
               "compiler GCC " __VERSION__ " "
#endif
               "time " __TIME__ " " __DATE__);
    log_detail(LOG_INFO,
               __FILE__,
               __func__,
               __LINE__,
               "Options:"
               " hightolow %d"
               " pidfile %s"
               " flap %d"
               " interface %s"
               " tolerance %d"
               " unit %d"
#ifndef NDEBUG
               " debug %d"
#endif
               " nodaemon %d"
               " verbose %d"
               " device %s",
               options->hightolow,
               (options->pidfile) ? options->pidfile : "!none!",
               options->flap,
               options_interface_str(options->interface),
               options->tolerance,
               options->unit,
#ifndef NDEBUG
               options->debug,
#endif
               options->nodaemon,
               options->verbose,
               (options->device) ? options->device : "!none!");

    (void)uname(&u);
    log(LOG_INFO,
        "System: sysname %s release %s version %s machine %s",
        u.sysname,
        u.release,
        u.version,
        u.machine);
}


/**
 * Log collected statistics.
 */
static void
log_statistics(struct statistics_t *statistics_p)
{
    log(LOG_NOTICE,
        "errors %lu warnings %lu",
        statistics_p->errors,
        statistics_p->warnings);
    log(LOG_NOTICE,
        "pulses %lu serial pulses %lu",
        statistics_p->pulses,
        statistics_p->serial_pulses);
    log(LOG_NOTICE,
        "round up %lu round down %lu out of tolerance %lu",
        statistics_p->round_up,
        statistics_p->round_down,
        statistics_p->round_exceeded);
    log(LOG_NOTICE,
        "precision loss %lu precision gain %lu",
        statistics_p->precision_loss,
        statistics_p->precision_gain);
}


/**
 * Exit upon a catastrophic failure.
 *
 * On most errors we log a warning containing the text "continuing",
 * set errno=0 and continue execution. When this is not possible,
 * call exit_failure().
 */
static void
exit_failure(void) {
    errno = 0;
    log_debug("Exiting upon failure");

    lockfile_clear(lockfile);
    pidfile_clear(pidfile);

    errno = 0;
    log(LOG_NOTICE,
        "Exited upon error, %lu pulses, %lu warnings, %lu errors",
        statistics.pulses,
        statistics.warnings,
        statistics.errors);

    exit(EXIT_FAILURE);
}


/**
 * Print help.
 *
 * Allow for files so that
 *   shm -h | more
 * works.
 *
 * @param  f  (in)  open file to print help text to.
 */
static void
help(FILE *f)
{
    char **p;
    static char *help_text[] = {
        PROGRAM_NAME ": Shared memory interfacing of PPS signal to NTPD\n",
        "Usage:\n",
        "  " PROGRAM_NAME " [-c] [-f] [-h] [-i <filename>] [-t <tolerance>] [-u <unit>] "
#ifndef NDEBUG
            "[-B] "
#endif
            "[-D] [-V] {-p | -s} <device>\n",
        "where\n",
        "  -c             Use high to low transition as PPS\n",
        "  -f             Flap parallel PPS output on PPS input\n",
        "  -h             Display this help text\n",
        "  -i <filename>  Create file <filename> with process ID\n",
        "  -u <unit>      NTP knows this as SHM unit number <unit>\n",
        "                 range 0 to 4, default 0\n"
        "  -t <tolerance> Acceptable milliseconds deviation from system "
            "clock,\n",
        "                 range 0 to 250000, default 40000\n",
        "  -p             PPS is on -Ack of parallel device\n",
        "  -s             PPS is on DCD of serial device\n",
        "  <device>       Device file for serial or parallel port\n",
        "and fault-finding options are\n",
#ifndef NDEBUG
        "  -B             Debug operation (also makes PPS inaccurate)\n",
#endif
        "  -D             Do not become a daemon\n",
        "  -V             Verbosely log to stderr, not to syslog\n",
        NULL
    };

    for (p = help_text; *p != NULL; p++) {
        (void)fputs(*p, f);
    }
}


/**
 * Parse command line options in argc and argv into options.
 *
 * @param  argc      (in)  Count of arguments in argv.
 * @param  argv      (in)  Vector of argument strings.
 * @param  options  (out)  Pointer to options record.
 *
 * @return Success or failure.
 * @retval   0  Options parsed fine.
 * @retval  !0  Error.
 *
 * @globals  opt*  getopt() variables
 */
static int
parse_options(int argc,
              char *argv[],
              struct options_t *options)
{
    char *error = NULL;
    int opt;

    /* Set defaults. */
#ifndef NDEBUG
    options->debug = 0;
#endif
    options->hightolow = 0;
    options->pidfile = NULL;
    options->nodaemon = 0;
    options->flap = 0;
    options->interface = OPTIONS_INTERFACE_NONE;
    options->tolerance = TOLERANCE_DEFAULT;
    options->unit = 0;
    options->verbose = 0;
    options->device = NULL;

    /* Parse parameters. */
    if (argc == 1) {
        help(stderr);
        return !0;
    }
    while ((opt = getopt(argc, argv, "cfhi:pst:u:BDV")) != EOF)
    {
        switch (opt) {
        case 'c':
            options->hightolow = 1;
            break;
        case 'f':
            options->flap = 1;
            break;
        case 'h':
            help(stdout);
            return !0;
        case 'i':
            options->pidfile = optarg;
            break;
        case 'p':
            if (options->interface) {
                error = "chose only one of parallel (-p) and serial (-s)";
            }
            options->interface = OPTIONS_INTERFACE_PARALLEL;
            break;
        case 's':
            if (options->interface) {
                error = "chose only one of serial (-s) and parallel (-p)";
            }
            options->interface = OPTIONS_INTERFACE_SERIAL;
            break;
        case 't':
        {
            unsigned long ul;
            char *end_p;

            ul = strtoul(optarg, &end_p, 10);
            if (end_p == optarg || *end_p != '\0') {
                error = "tolerance number invalid";
            }
            else if (ul > TOLERANCE_MAX) {
                error = "tolerance is greater than 0.25s";
            }
            else if (ul > INT_MAX) {
                error = "tolerance too large";
            }
            else
            {
                options->tolerance = (int)ul;
            }
        }
        case 'u':
        {
            unsigned long ul;
            char *end_p;

            ul = strtoul(optarg, &end_p, 10);
            if (end_p == optarg || *end_p != '\0') {
                error = "unit number invalid";
            }
            else if (ul > INT_MAX) {
                error = "unit number too large";
            }
            else
            {
                options->unit = (int)ul;
            }
        }
        break;
        case 'B':
#ifndef NDEBUG
            options->debug = 1;
#else
            error = "Debug mode not built in this program";
#endif
            break;
        case 'D':
            options->nodaemon = 1;
            break;
        case 'V':
            options->verbose = 1;
            break;
        default:
            error = "unknown option";
        }
    }

    /* Parse mandatory parameters */
    if (optind < argc) {
        options->device = argv[optind];
        optind++;
    }
    if (optind < argc) {
        error = "too many parameters";
    }

    /* Detect semantic errors.
     * List most severe error last.
     */
    if (options->interface == OPTIONS_INTERFACE_SERIAL && options->flap) {
        error = "selected serial port (-s) but asked to flap parallel "
            "signal (-f)";
    }
    if (options->interface == OPTIONS_INTERFACE_PARALLEL &&
        options->hightolow) {
        error = "selected parallel port (-p) but asked to follow serial "
            "high to low transitions (-c)";
    }
    if (!options->interface) {
        error = "chose one of serial (-s) and parallel (-p) port for "
            "PPS signal";
    }
    if (!options->device) {
        error = "<device> is required";
    }

    /* Cope with any errors.
     * Send them to stderr and to log so that sytax errors that creep
     * into system scripts can be found easily.
     */
    if (error) {
        fprintf(stderr, "%s: %s\n", PROGRAM_NAME, error);
        if (!options->verbose) {
            log(LOG_ERR,
                "Syntax error: %s",
                error);
        }
        help(stderr);
        return !0;
    }

    return 0;
}


/**
 * Signal handler for signals which request a program exit.
 *
 * @param signal  (in)  The operating system indicates which signal was raised.
 *
 * @globals signal_received  Altered to indicate a request for a clean exit
 *                           has been made.
 */
static void
signal_handler_exit(int signal)
{
    signal_received = SIGNAL_RECEIVED_EXIT;
    log_debug("Exit signal %d received", signal);
}


/**
 * Signal handler for signals which request a program reload.
 *
 * @param signal  (in)  The operating system indicates which signal was raised.
 *
 * @globals signal_received  Altered to indicate a request for a clean exit
 *                           has been made.
 */
static void
signal_handler_reload(int signal)
{
    signal_received = SIGNAL_RECEIVED_RELOAD;
    log_debug("Reload signal %d received", signal);
}


/**
 * Install signal handers.
 */
static void
signal_handlers(void)
{
    log_debug("Installing exit signal handler");
    if (signal(SIGINT, signal_handler_exit) == SIG_ERR) {
        log(LOG_WARNING,
            "Installing SIGINT exit signal handler failed, continuing");
        errno = 0;
    }
    if (signal(SIGTERM, signal_handler_exit) == SIG_ERR) {
        log(LOG_WARNING,
            "Installing SIGTERM exit signal handler failed, continuing");
        errno = 0;
    }

    log_debug("Installing reload signal handler");
    if (signal(SIGNAL_RECEIVED_RELOAD, signal_handler_reload) == SIG_ERR) {
        log(LOG_WARNING,
            "Installing reload signal handler failed, continuing");
        errno = 0;
    }
}


/**
 * Move from a foreground process to a daemon process.
 *
 * We try hard not to exit upon an error, but continue onwards.  So it
 * is a good idea to check the system log after starting the program.
 *
 * @param  quiet  (in)  Discard standard I/O.
 */
static void
become_daemon(int quiet)
{
    /* Set file creation mask so that "mode" argument to open() fully
     * describes permissions.
     */
    (void)umask((mode_t)0000);
    errno = 0;

    /* Prevent core dumps, as these can be used to overwrite files. */
    {
        struct rlimit coredump_limit;

        if (getrlimit(RLIMIT_CORE, &coredump_limit) == -1) {
            /* Ignore errors, just set the hard limit on coredump size
             * to zero too.
             */
            errno = 0;
            coredump_limit.rlim_max = (rlim_t)0;
        }
        coredump_limit.rlim_cur = (rlim_t)0;
        if (setrlimit(RLIMIT_CORE, &coredump_limit) == -1) {
            log(LOG_WARNING, "Failed to prevent coredumps, continuing");
            errno = 0;
        }
    }

    /* Fork a child process. */
    {
        pid_t pid;

        pid = fork();
        if (pid == (pid_t)(-1)) {
            log(LOG_ERR, "Error creating daemon process");
            exit_failure();
        }
        if (pid != (pid_t)0) {
            /* I am the parent process, retire. */
            exit(EXIT_SUCCESS);
        }
    }

    /* Disassociate from controlling terminal. So we don't hear HUP
     * signal when they log off.
     */
    if (setsid() == (pid_t)(-1)) {
        log(LOG_WARNING, "Failed to disassociate terminal, continuing");
        errno = 0;
    }

    /* Set current directory to root so that filesystems other than
     * root can be unmounted.
     */
    if (chdir("/") == -1) {
        log(LOG_WARNING, "Failed to change to root directory, continuing");
        errno = 0;
    }

    /* Close all open files, except stdio. */
    {
        struct rlimit file_limit;

        if (getrlimit(RLIMIT_NOFILE, &file_limit) == -1) {
            log(LOG_WARNING,
                "Failed to get number of file descriptors, continuing");
        }
        else {
            int f_max;
            int f;

            f_max = (int)file_limit.rlim_cur;
            for (f = 0; f < f_max; f++) {
                if (f != fileno(stdin) &&
                    f != fileno(stdout) &&
                    f != fileno(stderr)) {
                    /* f is probably not open, so ignore errors */
                    (void)close(f);
                }
            }
        }
        errno = 0;
    }

    /* Discard stdio. */
    if (quiet) {
        int null_f;

        null_f = open("/dev/null", O_RDWR);
        if (null_f == -1)
        {
            log(LOG_ERR, "Failed opening /dev/null for reading");
            errno = 0;
        }
        else {
            if (dup2(null_f, fileno(stdin)) == -1)
            {
                log(LOG_ERR, "Failed connecting /dev/null to stdin");
            }
            if (dup2(null_f, fileno(stdout)) == -1)
            {
                log(LOG_ERR, "Failed connecting /dev/null to stdout");
            }
            if (dup2(null_f, fileno(stderr)) == -1)
            {
                log(LOG_ERR, "Failed connecting /dev/null to stderr");
            }
            (void)close(null_f);
            errno = 0;
        }
    }
}


/**
 * Textual length of a Linux process identifier.
 *
 * Process IDs can be 32 bits, so when printed they need
 *   log10(2^32) + sizeof '\\n' + sizeof '\\0' = 12
 */
#define PID_STR_SIZE 12

/**
 * Create a file containing the process ID.
 *
 * This is used by System V-style init scripts.
 *
 * @param  name   (in)  Name of file to contain the process ID.
 *
 * @retval  null       File not created.
 * @retval  otherwise  The file name which was created.
 */
static char *
pidfile_set(char *name)
{
    int f;
    char s[PID_STR_SIZE]; 
    int length;

    if (name != NULL) {
        log_debug("Creating PID file %s", name);

        f = open(name, O_WRONLY|O_CREAT|O_TRUNC, S_IRUSR|S_IWUSR);
        if (f == -1) {
            log(LOG_WARNING, "%s: Failed creating PID file, continuing", name);
            errno = 0;
            return NULL;
        }

        length = snprintf(s, PID_STR_SIZE, "%u\n", (unsigned int)getpid());
        if (write(f, s, length) == -1) {
            log(LOG_WARNING,
                "%s: write(%d,\"%s\",%d) failed writing PID file, continuing",
                name,
                f,
                s,
                length);
            (void)close(f);
            (void)unlink(name);
            errno = 0;
            return NULL;
        }

        if (close(f) == -1) {
            log(LOG_WARNING, "%s: Failed closing PID file, continuing", name);
            (void)unlink(name);
            errno = 0;
            return NULL;
        }
    }

    return name;
}


/* Delete the file containing the process ID.
 *
 * In:
 *   name -- file to delete. Can be NULL to allow the top-level
 *           function to call this after pidfile_set() without
 *           testing pidfile_set()'s return value.
 *
 * A more sophisticated version would check that the file contains
 * our process ID before deleting it.
 */
static void
pidfile_clear(char *name)
{
    if (name != NULL) {
        log_debug("Deleting PID file %s", name);
        if (unlink(name) == -1) {
            log(LOG_WARNING, "%s: Failed deleting PID file, continuing", name);
            errno = 0;
        }
    }
}

/* Given the name of a RS-232 device, supply the name conventionally
 * used to lock the port.
 *
 * A more sophisticated version would follow symlinks and use the
 * truename of the device for deriving the lockfile name.
 *
 * A really sophisticated version would grab the major/minor of the
 * device file, and then search the directory for that major/minor and
 * use the name closest to "tty" (or failing that, the lowest of the
 * set of matching device names). Then multiple names for the same
 * device would be safer.
 */
static void
lockfile_name(char *filename,
              size_t filename_size,
              char *format,
              char *devicename)
{
    int length;
    char *basename;
    char *p;
    
    /* Find start of base name of serial device. */
    for (p = basename = devicename; *p != '\0'; p++) {
        if (*p == '/') {
            basename = p + 1;
        }
    }
    
    length = snprintf(filename, filename_size, format, basename);
    if (length > filename_size) {
        log(LOG_ERR,
            "%s: Serial port lockfile name is longer than a file name",
            filename);
        exit_failure();
    }
    log_debug("device %s has basename %s lockfile %s",
              devicename,
              basename,
              filename);
              
}


/* Create a file containing the process ID for locking the RS-232 port.
 *
 * This is used by convention to prevent processes fighting over the
 * serial port.
 *
 * A more sophisticated version confronted with an existing lock file
 * would check that the process ID was known to the system.  If it was
 * not known the stale lock file can be safely deleted and another
 * attempt made to lock it.
 *
 * In:
 *   name -- name of the RS-232 device to claim a lock for.
 */
static void
lockfile_set(char *name)
{
    int f;
    char s[PID_STR_SIZE];
    int length;

    log_debug("Testing serial port lock file %s", name);

    f = open(name, O_WRONLY|O_CREAT|O_EXCL, S_IRUSR|S_IWUSR);
    if (f == -1) {
        if (errno == EEXIST) {
            log(LOG_ERR,
                "%s: Lock file already exists, so "
                "something else is is using the serial port",
                name);
            *name = '\0';
            exit_failure();
        }
        else {
            log(LOG_ERR,
                "%s: error opening serial port lock file",
                name);
            *name = '\0';
            exit_failure();
        }
    }

    length = snprintf(s, PID_STR_SIZE, "%u\n", (unsigned int)getpid());
    if (write(f, s, length) == -1) {
        log(LOG_WARNING,
            "%s: write(%d,\"%s\",%d) failed writing lock file, continuing",
                name,
            f,
            s,
            length);
        (void)close(f);
        (void)unlink(name);
        errno = 0;
        *name = '\0';
        return;
    }

    if (close(f) == -1) {
        log(LOG_WARNING, "%s: Failed closing lock file, continuing", name);
        (void)unlink(name);
        errno = 0;
        *name = '\0';
        return;
    }
}


/* Delete the RS-232 lock file containing the process ID.
 *
 * In:
 *   name -- file to delete. Can be NULL to allow the top-level
 *           function to call this after pidfile_set() without
 *           testing pidfile_set()'s return value.
 *
 * A more sophisticated version would check that the file contains
 * our process ID before deleting it.
 */
static void
lockfile_clear(char *name)
{
    if (*name != '\0') {
        log_debug("Deleting lock file %s", name);
        if (unlink(name) == -1) {
            log(LOG_WARNING,
                "%s: Failed deleting lock file, continuing",
                name);
            errno = 0;
        }
    }
    *name = '\0';
}


/* Lower jitter from system activities on this process.
 *
 * Lock the processes pages to stop them paging, increase scheduling
 * priority, reduce jitter from scheduler.
 */
static void
lower_jitter(void)
{
    struct sched_param sp;

    log_debug("Lowering process jitter");

    /* Don't page this process. */
    if (mlockall(MCL_FUTURE) == -1)
    {
        log(LOG_WARNING,
            "mlockall() failed, this process may page, continuing");
    }

    /* Increase our priority when the OS schedules processes to the
     * maximum possible.
     */
    errno = 0;
    setpriority(PRIO_PROCESS, getpid(), -20);
    if (errno) {
        log(LOG_WARNING,
            "setpriority() failed, will run at normal priority, "
                "continuing");
        errno = 0;
    }

    /* Select a deterministic scheduling algorithm. */
    memset(&sp, 0, sizeof(sp));
    if ((sp.sched_priority = sched_get_priority_max(SCHED_FIFO)) == -1) {
        log(LOG_WARNING,
            "sched_get_priority_max() failed, won't alter scheduler, "
                "continuing");
        errno = 0;
    }
    else {
        if (sched_setscheduler(0, SCHED_FIFO, &sp) == -1) {
            log(LOG_WARNING,
                "sched_setscheduler() failed, "
                    "will run with standard scheduler, continuing");
            errno = 0;
        }
    }
}


/* Open a parallel port for PPS duty.
 *
 * In:
 *   name -- device name of parallel port with ppdev and
 *           parport modules loaded
 * Returns:
 *   File descriptor of parallel port The file descriptor is
 *   always valid, the program is exited otherwise.
 */
static int
parallel_open(char *name)
{
    int f;
    int mode;

    assert(name != NULL);
    log_debug("Opening parallel port %s",
              name);

    if ((f = open(name, O_RDWR)) == -1) {
        log(LOG_ERR,
            "%s: parallel device open() failed",
            name);
        exit_failure();
    }
    log_debug("Parallel port %s is file %d", name, f);

    if (ioctl(f, PPEXCL) == -1) {
        log(LOG_ERR,
            "%s: ioctl(%d,PPEXCL): Gaining exclusive use of parallel "
                "port failed",
            name,
            f);
        exit_failure();
    }

    if (ioctl(f, PPCLAIM) == -1) {
        log(LOG_ERR,
            "%s: ioctl(%d,PPCLAIM): Claiming parallel port failed",
            name,
            f);
        exit_failure();
    };

    mode = IEEE1284_MODE_BYTE; 
    if (ioctl(f, PPSETMODE, &mode) == -1) {
        log(LOG_ERR,
            "%s: ioctl(%d,PPSETMODE,IEEE1284_MODE_BTYE) failed",
            name,
            f);
        /* Release exclusive lock since we can't set mode. */
        (void)ioctl(f, PPRELEASE);
        exit_failure();
    };

    return f;
};


/* Open a serial port for PPS duty.
 *
 * In:
 *   name -- device name of parallel port with ppdev and
 *           parport modules loaded
 * Returns:
 *   File descriptor ofserial port. The file descriptor is
 *   always valid, the program is exited otherwise.
 */
static int
serial_open(char *name)
{
    int f;
    struct termios term;

    assert(name != NULL);
    log_debug("Opening serial port %s", name);

    /* Original code didn't have O_NOCTTY, so process could die if
     * serial port closed.  -GDT
     * Changed from O_RDWR to O_RDONLY|O_NONBLOCK as that looks
     * appears to be what kernel expects when using ioctl() interface.
     * -GDT
     */
    f = open(name, O_RDONLY|O_NONBLOCK|O_NOCTTY);
    if (f == -1) {
        log(LOG_ERR,
            "%s: serial device open() failed",
            name);
        exit_failure();
    }

    /* Set serial line discipline from here rather than relying on
     * user to fiddle with stty.  -GDT
     */
    if (tcgetattr(f, &term) == -1) {
        log(LOG_WARNING,
            "Failed to get serial port attributes, "
            "continuing without setting up serial port");
        errno = 0;
    }
    else {
        /* Save initial serial port settings for restoration on exit. */
        if (!original_term_valid) {
            original_term_valid = 1;
            memcpy(&original_term, &term, sizeof(term));
        }

        /* Reset to "raw" state and modify as follows... */
        (void)cfmakeraw(&term);
        /* Ignore RS-232 Break condition from floating data lines. */
        term.c_iflag |= IGNBRK;
        /* No XOn/XOff flow control. */
        term.c_iflag &= ~IXON;
        /* No parity or framing errors. */
        term.c_iflag |= IGNPAR;
        /* Ignore special characters. */
        term.c_lflag &= ~ISIG;
        /* No echo. */
        term.c_lflag &= ~ECHO;
        /* Ignore parity errors from floating data lines. */
        term.c_cflag &= ~PARENB;
        /* No CTS/RTS flow control. */
        term.c_cflag &= ~CRTSCTS;
        /* Don't drop DTR on close. */
        term.c_cflag &= ~HUPCL;
        /* Set CLOCAL for TIOCMIWAIT to work without looking at DCD
         * and DSR lines.  That tickles a bug in Linux kernels ealier
         * than late 2001.
         */
        term.c_cflag |= CLOCAL;
        if (tcsetattr(f, TCSANOW, &term) == -1) {
            log(LOG_WARNING,
                "Failed to set serial port attributes, continuing");
        }
    }

    log_debug("Serial port %s is file %d", name, f);
    return f;
}


/* Collect pulse-per-second pulses from Ack on the parallel port.
 *
 * In:
 *   f -- parallel port device
 *   sh -- shared memory
 *   tv_p -- time value
 *   flap -- reflect incoming PPS signal on pin 14.
 */
static void
parallel_pps(int f,
             struct time_shm *sh,
             struct timeval *tv_p,
             int flap)
{
    int none = 0;
    int polled;
    struct pollfd pp_poll;
    struct ppdev_frob_struct frobit;
    struct timezone tz;

    log_debug("Entering parallel PPS monitoring");

    pp_poll.fd = f;
    pp_poll.events = POLLIN;

    while (1)
    {
        do {
            log_debug("Waiting for tick");
            /* Original code had timeout here, not sure why. -GDT */
            polled = poll(&pp_poll, (unsigned)1, -1);
             /* Grab timestamp ASAP after event. */
            gettimeofday(tv_p, &tz);
            log_debug("Is this a tick?");
            if (__builtin_expect(signal_received, 0)) {
                errno = 0;
                log_debug("Not a tick, a signal");
                return;
            }
        } while (!polled);
        log_debug("Tick");

        if (__builtin_expect(polled == -1, 0)) {
            log(LOG_ERR, "poll() of parallel port failed");
            exit_failure();
        }

        /* Clear interrupt or you get a 40ms offset. yikes? */
        if (__builtin_expect(ioctl(f, PPCLRIRQ, &none) == -1, 0)) {
            log(LOG_ERR, "ioctl(%d,PPCLRIRQ) of parallel port failed", f);
            /* If we don't stop, we'll lock machine in a hard loop. */
            exit_failure();
        }

        /* Original code has && not & here, that only works by
         * accident. -GDT
         */
        if (__builtin_expect(pp_poll.revents & POLLIN, 1)) {
            /* Moved PPS reflection code inside of test for valid PPS
             * in.  -GDT
             */
            if (__builtin_expect(flap, 0)) {
                frobit.mask = PARPORT_CONTROL_AUTOFD;
                frobit.val = ~PARPORT_CONTROL_AUTOFD;
                if (ioctl (f, PPFCONTROL, &frobit) == -1) {
                    log_debug("Parallel port PPS echo assert signal failed. "
                              "Disabling future PPS echo to maintain "
                              "accuracy.");
                    flap = 0;
                }
            }

            statistics.pulses++;
            frobtrans(sh, tv_p);

            if (__builtin_expect(flap, 0)) {
                frobit.mask = PARPORT_CONTROL_AUTOFD;
                frobit.val = PARPORT_CONTROL_AUTOFD;
                if (ioctl (f, PPFCONTROL, &frobit) == -1) {
                    log_debug("Parallel port PPS echo clear signal failed. "
                              "Disabling future PPS echo to maintain "
                              "accuracy.");
                    flap = 0;
                }
            }
        }
    }
}


/* Collect pulse-per-second pulses from Ack on the parallel port.
 *
 * In:
 *   f -- parallel port device
 *   sh -- shared memory
 *   tv_p -- time value
 *   hightolow -- PPS signal is inverted
 */
static void
serial_pps(int f,
           struct time_shm *sh,
           struct timeval *tv_p,
           int hightolow)
{
    struct timezone tz;
    int status;
    int serial_signal;

    log_debug("Entering serial PPS monitoring");

    while (1) {
        log_debug("Waiting for tick");
        status = ioctl(f, TIOCMIWAIT, TIOCM_CAR);
        gettimeofday(tv_p, &tz); /* grab timestamp */

        if (__builtin_expect(status == -1, 0)) {
            log(LOG_ERR,
                "ioctl(%d,TIOCMIWAIT,0x%x) failed waiting for "
                "a pulse",
                f,
                TIOCM_CAR);
            exit_failure();
        }

        if (__builtin_expect(signal_received, 0)) {
            return;
        }

        log_debug("Tock");
        statistics.serial_pulses++;

        status = ioctl(f, TIOCMGET, &serial_signal);
        if (__builtin_expect(status == -1, 0)) {
            log(LOG_ERR, 
                "ioctl(%d,TIOCMGET,0x%x) failed",
                f,
                serial_signal);
            exit_failure();
        }

        if (__builtin_expect(hightolow, 0)) {
            if (__builtin_expect(!(serial_signal & TIOCM_CAR), 1)) {
                frobtrans(sh, tv_p);
                statistics.pulses++;
            }
        }
        else {
            if (__builtin_expect(serial_signal & TIOCM_CAR, 1)) {
                frobtrans(sh, tv_p);
                statistics.pulses++;
            }
        }
    }
}


/* Close parallel port.
 *
 * In:
 *   f -- parallel port device file
 */
static void
parallel_close(int f)
{
    log_debug("Closing parallel port");

    /* Release exclusive lock. */
    if (ioctl(f, PPRELEASE) == -1) {
        log(LOG_WARNING,
            "ioctl(%d,PPRELEASE) failed, continuing", f);
        errno = 0;
    }

    if (close(f) == -1) {
        log(LOG_ERR, "close(%d) failed, continuing", f);
        errno = 0;
    }
}


/* Close serial port.
 *
 * In:
 *   f -- serial port device file
 */
static void
serial_close(int f)
{
    log_debug("Closing serial port");

    if (original_term_valid) {
        log_debug("Resetting terminal");
        if (tcsetattr(f, TCSANOW, &original_term) == -1) {
            log(LOG_WARNING,
                "Failed to reset serial port attributes to original values, "
                "continuing");
            errno = 0;
        }
    }

    if (close(f) == -1) {
        log(LOG_ERR, "close(%d) failed, continuing", f);
        errno = 0;
    }
}


/* Allocate a time_shm of shared memory for chatting with NTPD.
 *
 * In:
 *   unit -- NTP unit number, specified in NTP as 127.127.28.<unit>
 * Returns:
 *  pointer to the shared memory
 */
static struct time_shm *
attach_shm(int unit)
{
    int shm_id;
    void *sh;

    assert(unit >= 0);
    log_debug("Attaching shared memory, unit %d", unit);
    shm_id = shmget(0x4e545030 + unit,
                    sizeof(struct time_shm),
                    IPC_CREAT | 0700);
    if (shm_id == -1) {
        log(LOG_ERR, "shmget() failed");
        exit_failure();
    };

    sh = shmat(shm_id, NULL, 0);
    if (sh == (void *)(-1) || sh == NULL) {
        log(LOG_ERR,
            "shmat() failed with value %lu",
            (unsigned long)sh);
        exit_failure();
    };

    log_debug("Shared memory attached, id %d addr %p",
              shm_id,
              sh);
    return (struct time_shm *)sh;
}


/* The integer distance between points on a line 'a' and 'b'.
 *
 * In:
 *   a, b -- values on a line of integers
 * Returns:
 *   distance between the values on the line
 */
static inline int
difference(int a,
           int b)
{
    return (a > b) ? (a - b) : (b - a);
}


/* Update the estimate of precision.
 *
 * In:
 *   offset -- time difference from system time, in usecs
 * Out:
 *   precision_est_p -- pointer to estimate of precision
 */
static void
update_offset(int offset,
              int *precision_est_p)
{
    static int last_reading = 0;
    static int average_offset = 0;
    int target_precision;

    /* How far is this reading from the last one?
     * On average, how much are these readings varying?
     * In units of 16 microseconds, exponential average
     */
    average_offset = (average_offset * 15 / 16) +
                     difference(last_reading, offset);

    log_debug("diff %d off %d avgdiff %0.1f",
              difference(last_reading, offset),
              offset,
              average_offset / 16.0);

    last_reading = offset;

    /* Adjust our precision estimate based upon how well our readings
     * are agreeing with each other. This will give low values when
     * our system clock's rate is off or due to system jitter, but
     * that's actually reasonable.
     *
     * The magic constants are based on:
     *   average_offset/16/1000000=2^(target_precision/32)
     * Or, to put it another way, our estimated precision is equal to
     * our average offset of sequential readings after units are
     * converted
     *
     * average_offset is in units of 16ths of a microsecond
     * target_precision is in units of 32nds of a power of 2
     */
    if      (average_offset <    61) target_precision = -18 * 32;
    else if (average_offset <   122) target_precision = -17 * 32;
    else if (average_offset <   244) target_precision = -16 * 32;
    else if (average_offset <   488) target_precision = -15 * 32;
    else if (average_offset <   976) target_precision = -14 * 32;
    else if (average_offset <  1953) target_precision = -13 * 32;
    else if (average_offset <  3906) target_precision = -12 * 32;
    else if (average_offset <  7812) target_precision = -11 * 32;
    else if (average_offset < 15625) target_precision = -10 * 32;
    else if (average_offset < 31250) target_precision =  -9 * 32;
    else                             target_precision =  -8 * 32;
 
    if (*precision_est_p < target_precision) {
        /* Lose precision fast. */
        *precision_est_p += 4;
        statistics.precision_loss++;
    }
    else if (*precision_est_p > target_precision) {
        /* Gain precision slow */
        (*precision_est_p)--;
        statistics.precision_gain++;
    }

    log_debug("targ_prec %.1f precision %.1f\n",
              target_precision/32.0,
              *precision_est_p/32.0);    
}


/* Put a timestamp to the shared memory.
 *
 * In:
 *   sh -- shared memory
 *   cloc_sec, cloc_usec -- time PPS pulse arrived
 *   sys_sec, sys_usec -- system time
 *   precision_est -- estimate of reliability of cloc_usec
 */
static void
stamp_shm(struct time_shm *sh,
          time_t cloc_sec,
          int cloc_usec,
          time_t sys_sec,
          int sys_usec,
          int precision_est)
{
    sh->shm_mode = 1;
    sh->leap_indicator = 0;
    sh->is_valid = 0; /* this is perhaps overly paranoid */
    sh->stamp_count++;

    __asm__ __volatile__("": : :"memory");

    sh->precision = precision_est/32;
    sh->clock_sec = cloc_sec;
    sh->clock_usec = cloc_usec;
    sh->receive_sec = sys_sec;
    sh->receive_usec = sys_usec;

    __asm__ __volatile__("": : :"memory");

    sh->stamp_count++;
    sh->is_valid = 1;
    log_debug("syssec %d sysusec %d refsec %d refusec %d",
              (int) sys_sec,
              (int) sys_usec,
              (int) cloc_sec,
              (int) cloc_usec);
};


/* Round PPS transition and put it to shared memory.
 *
 * In:
 *   sh -- shared memory
 *   tv_p -- system time PPS pulse arrived
 */
static void
frobtrans(struct time_shm *sh,
          struct timeval *tv_p)
{
    /* This is our current estimate of precision. Our microseconds
     * estimated error is 1000000*2^(precision_est/32)
     */
    static int precision_est = (PRECISION * 32);

    if (tv_p->tv_usec > (1000000 - options.tolerance)) {
        log_debug("Round up");
        update_offset(tv_p->tv_usec - 1000000,
                      &precision_est);
        stamp_shm(sh,
                  tv_p->tv_sec + 1,
                  ASSUME_DELAY,
                  tv_p->tv_sec,
                  tv_p->tv_usec,
                  precision_est);
        statistics.round_up++;
    }
    else if (tv_p->tv_usec < options.tolerance) {
        log_debug("Round down");
        update_offset(tv_p->tv_usec,
                      &precision_est);
        stamp_shm(sh,
                  tv_p->tv_sec,
                  ASSUME_DELAY,
                  tv_p->tv_sec,
                  tv_p->tv_usec,
                  precision_est);
        statistics.round_down++;
    }
    else {
      log(LOG_INFO,
          "Out of range: timestamp: %ld sec %ld usec, tolerance: %ld",
          tv_p->tv_sec,
          tv_p->tv_usec,
          options.tolerance);
      statistics.round_exceeded++;
    }
}


int
main(int argc,
     char *argv[])
{
    int f;
    struct time_shm *sh;
    struct timeval tv;

    if (parse_options(argc, argv, &options)) {
        exit(EXIT_PARSE_FAILURE);
    }
    log_options(&options);

    if (!options.nodaemon) {
        become_daemon(!options.verbose);
    }

    log(LOG_NOTICE,
        "Running %s with process id %d",
        options.nodaemon ? "in foreground" : "as daemon",
        getpid());

    pidfile = pidfile_set(options.pidfile);
    if (options.interface == OPTIONS_INTERFACE_SERIAL) {
        lockfile_name(lockfile,
                      LOCKFILE_SIZE,
                      LOCKFILE_FORMAT,
                      options.device);
        lockfile_set(lockfile);
    }

    signal_handlers();

    while (signal_received != SIGNAL_RECEIVED_EXIT) {
        signal_received = SIGNAL_RECEIVED_NONE;

        if (options.interface == OPTIONS_INTERFACE_PARALLEL) {
            f = parallel_open(options.device);
        }
        else {
            f = serial_open(options.device);
        }

        lower_jitter();

        sh = attach_shm(options.unit);

        if (options.interface == OPTIONS_INTERFACE_PARALLEL) {
            parallel_pps(f, sh, &tv, options.flap);
        }
        else {
            serial_pps(f, sh, &tv, options.hightolow);
        }

        /* To have returned from a ..._pps() function there must have
         * been a signal to the daemon.
         */
        if (signal_received == SIGNAL_RECEIVED_EXIT) {
            log(LOG_INFO,
                "Exiting as requested by signal");
        }
        else if (signal_received == SIGNAL_RECEIVED_RELOAD) {
            log(LOG_NOTICE,
                "Reloading as requested by signal");
        }
        else {
            log(LOG_ERR,
                "Unexpected and unhandled signal %d",
                signal_received);
            exit_failure();
        }

        if (options.interface == OPTIONS_INTERFACE_PARALLEL) {
            parallel_close(f);
        }
        else {
            serial_close(f);
        }

        /* Print statistics on exit or HUP reload. */
        log_statistics(&statistics);
    }

    lockfile_clear(lockfile);
    pidfile_clear(pidfile);

    log(LOG_NOTICE,
        "Exited normally. %lu warnings, %lu errors.",
        statistics.warnings,
        statistics.errors);
    return 0;
}

