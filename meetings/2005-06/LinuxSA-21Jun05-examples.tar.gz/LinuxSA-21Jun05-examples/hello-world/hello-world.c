/* A hello-world program. */
int main (int argv, char** argc){
  printf("Hello World\n");
  return(0);
}
