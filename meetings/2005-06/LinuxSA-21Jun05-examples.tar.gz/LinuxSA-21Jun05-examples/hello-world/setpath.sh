#!/bin/bash

export PATH="/usr/local/crosstool/gcc-3.4.2-glibc-2.2.5/arm-unknown-linux-gnu/arm-unknown-linux-gnu/bin:$PATH"
